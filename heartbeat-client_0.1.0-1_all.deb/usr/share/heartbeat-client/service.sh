#!/usr/bin/env bash

CONFIGURATION='/etc/heartbeat-client/configuration'

while true; do
    if [[ -f "${CONFIGURATION}" ]]; then
        source "${CONFIGURATION}"
    fi;

    /usr/share/heartbeat-client/heartbeat-client.sh
    sleep ${INTERVAL-900}
done