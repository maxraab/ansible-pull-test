#!/usr/bin/env bash

# set -x

# the configuration file should look like:
#
# URL='http://localhost:5080/server'
# ID='3fa85f64-5717-4562-b3fc-2c963f66afa6'
# TAGS=('raspi' 'testing' 'ci')

# variables
CONFIGURATION='/etc/heartbeat-client/configuration'
BASE_DIRECTORY='/usr/share/heartbeat-client'
TEMPLATE="${1-default}"
URL='http://165.232.118.37/Server'
MACHINE_ID_UNFORMATTED="$(cat /etc/machine-id)"
ID="${MACHINE_ID_UNFORMATTED:0:8}-${MACHINE_ID_UNFORMATTED:8:4}-${MACHINE_ID_UNFORMATTED:12:4}-${MACHINE_ID_UNFORMATTED:16:4}-${MACHINE_ID_UNFORMATTED:20}"
TAGS=()

# read from configuration file
# the file is optional an can override all the variables we have decalred so far
if [[ -f "${CONFIGURATION}" ]]; then
    source "${CONFIGURATION}"
fi;

# gather necessary information
IP="$(hostname -I | cut -d' ' -f1)"
HOSTNAME="$(hostname)"

# build json
JSON=$(mktemp /tmp/heartbeat.XXXXX)
cat "${BASE_DIRECTORY}/templates/${TEMPLATE}.tpl" > "${JSON}"

# load modules
for module in ${BASE_DIRECTORY}/modules/*.mod;
do
    source "${module}"
    eval "${MODULE_COMMAND}" "${JSON}" 
done

# send the request
curl \
  -X PUT "${URL}" \
  -H 'content-type: text/json' \
  -d @"${JSON}" \
  &> /dev/null

if [[ "${DEBUG}" == "false" ]]; then
    rm "${JSON}"
fi